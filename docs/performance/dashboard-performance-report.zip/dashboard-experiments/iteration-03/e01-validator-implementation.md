# E01 validator implementation

Release build succeeded (exit 0; see e01-validator-build.log and e01-validator-build.exit). Scoped format completed successfully. No validator or unit tests were executed.

```sh
dotnet build code/FinanceManager.Benchmarks/FinanceManager.Benchmarks.csproj -c Release
dotnet format ./code/FinanceManager.slnx --include code/FinanceManager.Benchmarks/Program.cs code/FinanceManager.Benchmarks/Validation/LongBondFixtureValidator.cs
```

## Source diff after formatting

```diff
diff --git a/code/FinanceManager.Benchmarks/Program.cs b/code/FinanceManager.Benchmarks/Program.cs
index 0df717c8..02fa7ba0 100644
--- a/code/FinanceManager.Benchmarks/Program.cs
+++ b/code/FinanceManager.Benchmarks/Program.cs
@@ -10,6 +10,9 @@ internal static class Program
     {
         try
         {
+            if (args.Contains("--validate-e01-long-bond", StringComparer.OrdinalIgnoreCase))
+                return await LongBondFixtureValidator.Run(args) ? 0 : 1;
+
             if (args.Contains("--validate", StringComparer.OrdinalIgnoreCase))
                 return await EndpointValidator.Run() ? 0 : 1;
 
diff --git a/code/FinanceManager.Benchmarks/Validation/LongBondFixtureValidator.cs b/code/FinanceManager.Benchmarks/Validation/LongBondFixtureValidator.cs
new file mode 100644
index 00000000..f6fcf745
--- /dev/null
+++ b/code/FinanceManager.Benchmarks/Validation/LongBondFixtureValidator.cs
@@ -0,0 +1,89 @@
+using FinanceManager.Benchmarks.Hosting;
+using FinanceManager.Domain.FinancialAccounts.Bond.Entities;
+using FinanceManager.Domain.FinancialAccounts.Bond.Repositories;
+using FinanceManager.Domain.FinancialAccounts.Shared.Repositories;
+using Microsoft.Extensions.DependencyInjection;
+using System.Text.Json;
+
+namespace FinanceManager.Benchmarks.Validation;
+
+internal static class LongBondFixtureValidator
+{
+    public static async Task<bool> Run(string[] args)
+    {
+        try
+        {
+            string Argument(string name)
+            {
+                var index = Array.FindIndex(args, x => x.Equals(name, StringComparison.OrdinalIgnoreCase));
+                if (index < 0 || index + 1 >= args.Length || args[index + 1].StartsWith("--", StringComparison.Ordinal))
+                    throw new ArgumentException($"Missing {name} value.");
+                return args[index + 1];
+            }
+
+            var mode = Argument("--e01-mode");
+            var output = Argument("--e01-output");
+            if (mode is not ("fixture" or "control")) throw new ArgumentException("Mode must be fixture or control.");
+            if (!Path.IsPathFullyQualified(output) || File.Exists(output)) throw new ArgumentException("Output must be an absolute path that does not exist.");
+
+            var environment = await BenchmarkEnvironment.GetOrCreate();
+            var scenario = environment.Scenario;
+            using var scope = environment.CreateHostScope();
+            var repository = scope.ServiceProvider.GetRequiredService<IFinancialAccountRepository>();
+            BondAccount? account = null;
+            await foreach (var item in repository.GetAccounts<BondAccount>(scenario.UserId, scenario.Start, scenario.End))
+                if (item.AccountId == 5) account = item;
+
+            object? proof = null;
+            if (mode == "control")
+            {
+                if (account is not null) throw new InvalidOperationException("Control contains account 5.");
+            }
+            else
+            {
+                if (account is null) throw new InvalidOperationException("Fixture account 5 is absent.");
+                var details = (await scope.ServiceProvider.GetRequiredService<IBondDetailsRepository>().GetByIdsAsync([9])).Single();
+                var count = 0;
+                decimal startPrice = 0, endPrice = 0;
+                DateTime postingDate = default;
+                for (var date = scenario.Start.Date; date <= scenario.End.Date; date = date.AddDays(1))
+                {
+                    var selected = account.GetThisOrNextOlder(date, 9);
+                    if (selected is null || selected.EntryId != 7) throw new InvalidOperationException($"Unexpected selection on {date:yyyy-MM-dd}.");
+                    postingDate = selected.PostingDate;
+                    var price = selected.GetPriceAt(DateOnly.FromDateTime(date), details);
+                    if (price <= 0) throw new InvalidOperationException($"Nonpositive price on {date:yyyy-MM-dd}.");
+                    if (count++ == 0) startPrice = price;
+                    endPrice = price;
+                }
+                var ageDays = (scenario.Start.Date - postingDate.Date).Days;
+                if (count == 0 || ageDays < 3650) throw new InvalidOperationException("Fixture posting age or window is invalid.");
+                proof = new { accountId = 5, bondId = 9, entryId = 7, postingDate, ageDays, selectedCount = count, startPrice, endPrice };
+                Console.WriteLine($"Selected {count} dates; start price {startPrice}, end price {endPrice}.");
+            }
+
+            async Task<JsonElement> Overview(DateTime start, DateTime end)
+            {
+                var route = $"api/Dashboard/overview?userId={scenario.UserId}&currencyId={scenario.CurrencyId}&start={Uri.EscapeDataString(start.ToString("O"))}&end={Uri.EscapeDataString(end.ToString("O"))}";
+                using var response = await environment.Client.GetAsync(route);
+                response.EnsureSuccessStatusCode();
+                using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
+                var series = json.RootElement.GetProperty("netWorthSeries");
+                if (series.ValueKind != JsonValueKind.Array || series.GetArrayLength() == 0) throw new InvalidOperationException("netWorthSeries is empty.");
+                return json.RootElement.Clone();
+            }
+
+            var full = await Overview(scenario.Start, scenario.End);
+            var month = await Overview(scenario.LastMonthStart, scenario.End);
+            var report = new { mode, scenario.UserId, scenario.CurrencyId, scenario.Start, scenario.End, scenario.LastMonthStart, proof, full, month };
+            await using var stream = new FileStream(output, FileMode.CreateNew, FileAccess.Write);
+            await JsonSerializer.SerializeAsync(stream, report, new JsonSerializerOptions { WriteIndented = true });
+            return true;
+        }
+        catch (Exception ex)
+        {
+            Console.Error.WriteLine(ex.Message);
+            return false;
+        }
+    }
+}
\ No newline at end of file
```
