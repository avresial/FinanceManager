```

BenchmarkDotNet v0.15.8, macOS Tahoe 26.6.2 (25G83) [Darwin 25.6.0]
Apple M1 Max, 1 CPU, 10 logical and 10 physical cores
.NET SDK 10.0.302
  [Host] : .NET 10.0.10 (10.0.10, 10.0.1026.32716), Arm64 RyuJIT armv8.0-a

Toolchain=InProcessEmitToolchain  IterationCount=10  IterationTime=250ms  
WarmupCount=3  

```
| Method                                  | Mean     | Error    | StdDev   | Median   | P95      | Ratio | RatioSD | Gen0      | Gen1     | Allocated | Alloc Ratio |
|---------------------------------------- |---------:|---------:|---------:|---------:|---------:|------:|--------:|----------:|---------:|----------:|------------:|
| &#39;GET api/Dashboard/overview (6 months)&#39; | 65.87 ms | 4.932 ms | 3.262 ms | 64.98 ms | 70.82 ms |  1.00 |    0.07 | 1000.0000 | 500.0000 |   6.97 MB |        1.00 |
| &#39;GET api/Dashboard/overview (1 month)&#39;  | 38.57 ms | 0.904 ms | 0.598 ms | 38.61 ms | 39.47 ms |  0.59 |    0.03 |  666.6667 | 166.6667 |   4.48 MB |        0.64 |
